// app/src/main/java/com/example/students/ui/StudentMainActivity.java
package com.example.students.ui;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import com.example.students.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class StudentMainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_student_main);

        BottomNavigationView nav = findViewById(R.id.studentBottomNav);
        nav.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Fragment f;
                String title;
                int id = item.getItemId();
                if (id == R.id.nav_home) {
                    f = new HomeFragment();
                    title = "Домой";
                } else if (id == R.id.nav_grades) {
                    f = new GradesFragment();
                    title = "Оценки";
                } else if (id == R.id.nav_profile) {
                    f = new ProfileFragment();
                    title = "Профиль";
                } else {
                    return false;
                }
                setTitle(title);
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.studentFragmentContainer, f)
                        .commit();
                return true;
            }
        });
    }
}

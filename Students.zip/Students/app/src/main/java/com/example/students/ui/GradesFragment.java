// app/src/main/java/com/example/students/ui/GradesFragment.java
package com.example.students.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.example.students.R;
import com.example.students.model.GradeItem;
import java.util.ArrayList;
import java.util.List;

public class GradesFragment extends Fragment {
    private SwipeRefreshLayout swipe;
    private RecyclerView rv;
    private GradesAdapter adapter;
    private List<GradeItem> data = new ArrayList<>();

    @Override
    public View onCreateView(@NonNull LayoutInflater li, ViewGroup cg, Bundle b) {
        return li.inflate(R.layout.fragment_grades, cg, false);
    }

    @Override
    public void onViewCreated(@NonNull View v, Bundle b) {
        swipe = v.findViewById(R.id.swipeRefresh);
        rv    = v.findViewById(R.id.rvGrades);
        rv.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new GradesAdapter(getContext(), data);
        rv.setAdapter(adapter);

        swipe.setOnRefreshListener(this::loadGrades);
        loadGrades();
    }

    private void loadGrades() {
        swipe.setRefreshing(true);
        // TODO: вместо заглушки вызвать реальный API
        data.clear();
        data.add(new GradeItem("Математика", new int[]{2,3,4,5}, 3.5f));
        data.add(new GradeItem("Русский язык", new int[]{4,5,5,4}, 4.5f));
        data.add(new GradeItem("История", new int[]{3,3,4}, 3.3f));
        adapter.notifyDataSetChanged();
        swipe.setRefreshing(false);
    }
}

package com.example.students.model;

public class ClassItem {
    public String id;
    public String name;
}

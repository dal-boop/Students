package com.example.students.model;

/**
 * Модель для таблицы subjects (id, name, class_id).
 */
public class SubjectItem {
    public String id;
    public String name;
    public String class_id;
}

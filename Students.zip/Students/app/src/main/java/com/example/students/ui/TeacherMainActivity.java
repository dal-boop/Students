package com.example.students.ui;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.example.students.R;

public class TeacherMainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_teacher_main);
        // TODO: список классов → ввод оценок
    }
}

package com.example.students.model;

/**
 * Модель для users (id, email, full_name, role, class_id).
 */
public class User {
    public String id;
    public String email;
    public String full_name;
    public String role;
    public String class_id;
}
